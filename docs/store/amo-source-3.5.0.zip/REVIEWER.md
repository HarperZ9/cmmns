Daylight Commons 3.5.0: source for the generated files in the Firefox package

The xpi holds two generated files. Everything else in it is hand-written source or plain data,
shipped as is.

  core.bundle.js  made by scripts/build.mjs from src/core (one file per module, concatenated in a
                  fixed order and wrapped in one function; no minifying, no transpiling)
  ocr.bundle.js   made the same way from src/ocr

Remake and compare them:

  1. Install Node.js 22 or later. No npm install is needed: the project has no dependencies.
  2. Unzip this archive into an empty folder.
  3. Unzip the submitted radar-firefox-3.5.0.xpi into src/ext inside that folder.
  4. Run: node scripts/build.mjs
     It rewrites src/ext/core.bundle.js and src/ext/ocr.bundle.js.
  5. Compare them with the files from the xpi; they are identical byte for byte. For example:
       git diff --no-index <xpi copy>/core.bundle.js src/ext/core.bundle.js
     prints nothing.

The whole repository, with its history and tests, is public:
  https://github.com/HarperZ9/daylight-commons (tag v3.5.0)

Licence: AGPL-3.0-only for code (LICENSE), CC BY 4.0 for data and docs.
